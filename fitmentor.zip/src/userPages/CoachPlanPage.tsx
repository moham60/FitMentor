import { useEffect, useState } from "react";
import { Calendar, Check, Dumbbell, Clock, Trophy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import MainLayout from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

interface PlanMuscle {
    id: string;
    muscle_id: string;
    muscle_name: string;
    exercise_count: number;
    sets: number;
    reps: string;
    order_index: number;
    equipment: string | null;
    exercise_description: string | null;
}

interface CoachPlan {
    id: string;
    name: string;
    type: string;
    description: string | null;
    image_url: string | null;
}

interface WorkoutSession {
    date: string;
    completed_exercises: string[];
    total_exercises: number;
}

export default function CoachPlanPage() {
    const { user } = useAuth();
    const { toast } = useToast();
    const [loading, setLoading] = useState(true);
    const [coachPlan, setCoachPlan] = useState<CoachPlan | null>(null);
    const [planMuscles, setPlanMuscles] = useState<PlanMuscle[]>([]);
    const [todayCheckedExercises, setTodayCheckedExercises] = useState<Set<string>>(new Set());
    const [monthlyWorkouts, setMonthlyWorkouts] = useState<WorkoutSession[]>([]);
    const [planStatus, setPlanStatus] = useState<{
        status: string;
        started_at: string;
        expires_at: string;
    } | null>(null);

    useEffect(() => {
        if (!user) return;
        fetchCoachPlan();
        fetchTodayWorkout();
        fetchMonthlyWorkouts();
    }, [user]);

    const fetchCoachPlan = async () => {
        try {
            setLoading(true);

            // جلب معلومات الاشتراك من profiles
            const { data: profile, error: profileError } = await supabase
                .from('profiles')
                .select(`
                    coach_plan_id,
                    coach_plan_status,
                    coach_plan_started_at,
                    coach_plan_expires_at,
                    coach_plans!profiles_coach_plan_id_fkey (
                        id,
                        name,
                        type,
                        description,
                        image_url
                    )
                `)
                .eq('user_id', user!.id)
                .single();

            if (profileError) throw profileError;

            if (!profile?.coach_plan_id || profile.coach_plan_status !== 'active') {
                setCoachPlan(null);
                setLoading(false);
                return;
            }

            if (profile.coach_plan_started_at && profile.coach_plan_expires_at) {
                setPlanStatus({
                    status: profile.coach_plan_status || 'active',
                    started_at: profile.coach_plan_started_at,
                    expires_at: profile.coach_plan_expires_at
                });
            }

            setCoachPlan(profile.coach_plans as any);

            // جلب تمارين الخطة
            const { data: muscles, error: musclesError } = await supabase
                .from('plan_muscles')
                .select('*')
                .eq('plan_id', profile.coach_plan_id)
                .order('order_index', { ascending: true });

            if (musclesError) throw musclesError;

            setPlanMuscles(muscles || []);
        } catch (err: any) {
            console.error('Error fetching coach plan:', err);
            toast({
                title: "خطأ",
                description: "حدث خطأ أثناء جلب البيانات",
                variant: "destructive"
            });
        } finally {
            setLoading(false);
        }
    };

    const fetchTodayWorkout = async () => {
        try {
            const today = new Date().toISOString().split('T')[0];

            const { data: session, error } = await supabase
                .from('user_workout_sessions')
                .select('id, notes')
                .eq('user_id', user!.id)
                .eq('session_date', today)
                .maybeSingle();

            if (error) throw error;

            const completed = new Set<string>();
            if (session?.notes) {
                try {
                    const checkedIds = JSON.parse(session.notes);
                    if (Array.isArray(checkedIds)) {
                        checkedIds.forEach(id => completed.add(id));
                    }
                } catch (e) {
                    // notes is not JSON, ignore
                }
            }

            setTodayCheckedExercises(completed);
        } catch (err) {
            console.error('Error fetching today workout:', err);
        }
    };

    const fetchMonthlyWorkouts = async () => {
        try {
            const now = new Date();
            const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
            const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);

            const { data: sessions, error } = await supabase
                .from('user_workout_sessions')
                .select('session_date, notes')
                .eq('user_id', user!.id)
                .gte('session_date', firstDay.toISOString().split('T')[0])
                .lte('session_date', lastDay.toISOString().split('T')[0]);

            if (error) throw error;

            const workoutMap = new Map<string, WorkoutSession>();

            sessions?.forEach((session: any) => {
                const date = session.session_date;
                let completedExercises: string[] = [];
                
                if (session.notes) {
                    try {
                        const checkedIds = JSON.parse(session.notes);
                        if (Array.isArray(checkedIds)) {
                            completedExercises = checkedIds;
                        }
                    } catch (e) {
                        // notes is not JSON, ignore
                    }
                }

                workoutMap.set(date, {
                    date,
                    completed_exercises: completedExercises,
                    total_exercises: planMuscles.length
                });
            });

            setMonthlyWorkouts(Array.from(workoutMap.values()));
        } catch (err) {
            console.error('Error fetching monthly workouts:', err);
        }
    };

    const handleCheckExercise = async (muscleId: string, checked: boolean) => {
        try {
            const today = new Date().toISOString().split('T')[0];

            // جلب أو إنشاء session
            const { data: existingSession } = await supabase
                .from('user_workout_sessions')
                .select('id, notes')
                .eq('user_id', user!.id)
                .eq('session_date', today)
                .maybeSingle();

            let sessionId: string;
            let currentChecked: Set<string> = new Set();

            if (existingSession) {
                sessionId = existingSession.id;
                // قراءة التمارين الحالية
                if (existingSession.notes) {
                    try {
                        const checkedIds = JSON.parse(existingSession.notes);
                        if (Array.isArray(checkedIds)) {
                            currentChecked = new Set(checkedIds);
                        }
                    } catch (e) {
                        // notes is not JSON, start fresh
                    }
                }
            } else {
                const { data: newSession, error: sessionError } = await supabase
                    .from('user_workout_sessions')
                    .insert({
                        user_id: user!.id,
                        session_date: today,
                        status: 'in_progress',
                        notes: JSON.stringify([])
                    })
                    .select()
                    .single();

                if (sessionError) throw sessionError;
                sessionId = newSession.id;
            }

            // تحديث القائمة
            if (checked) {
                currentChecked.add(muscleId);
            } else {
                currentChecked.delete(muscleId);
            }

            // حفظ التحديث
            const { error: updateError } = await supabase
                .from('user_workout_sessions')
                .update({
                    notes: JSON.stringify(Array.from(currentChecked)),
                    status: currentChecked.size === planMuscles.length ? 'completed' : 'in_progress'
                })
                .eq('id', sessionId);

            if (updateError) throw updateError;

            setTodayCheckedExercises(currentChecked);
            fetchMonthlyWorkouts();

            toast({
                title: checked ? "✓ تم تسجيل التمرين" : "تم إلغاء التسجيل",
                description: checked ? "تم حفظ التمرين بنجاح" : "تم حذف التمرين"
            });
        } catch (err: any) {
            console.error('Error checking exercise:', err);
            toast({
                title: "خطأ",
                description: err.message || "حدث خطأ أثناء حفظ التمرين",
                variant: "destructive"
            });
        }
    };

    const getMonthCalendar = () => {
        const now = new Date();
        const year = now.getFullYear();
        const month = now.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startDayOfWeek = firstDay.getDay();

        const days: (number | null)[] = [];
        for (let i = 0; i < startDayOfWeek; i++) {
            days.push(null);
        }
        for (let i = 1; i <= daysInMonth; i++) {
            days.push(i);
        }

        return days;
    };

    const getDayWorkout = (day: number | null) => {
        if (!day) return null;
        const now = new Date();
        const date = new Date(now.getFullYear(), now.getMonth(), day)
            .toISOString()
            .split('T')[0];
        return monthlyWorkouts.find(w => w.date === date);
    };

    if (loading) {
        return (
            <MainLayout title="خطة المدرب">
                <div className="flex items-center justify-center min-h-[400px]">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                </div>
            </MainLayout>
        );
    }

    if (!coachPlan) {
        return (
            <MainLayout title="خطة المدرب">
                <div className="flex items-center justify-center min-h-[400px]">
                    <div className="text-center">
                        <Dumbbell className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                        <h3 className="text-xl font-semibold mb-2">لا توجد خطة نشطة</h3>
                        <p className="text-muted-foreground mb-4">
                            اشترك في خطة مدرب لبدء التمرين
                        </p>
                        <Button onClick={() => window.location.href = '/subscription'}>
                            تصفح الخطط
                        </Button>
                    </div>
                </div>
            </MainLayout>
        );
    }

    const todayProgress = (todayCheckedExercises.size / planMuscles.length) * 100;

    return (
        <MainLayout title="خطة المدرب">
            <div className="container mx-auto p-4 space-y-6">
                {/* معلومات الخطة */}
                <Card className="border-2 border-primary/20">
                    <CardHeader>
                        <div className="flex items-center justify-between">
                            <div>
                                <CardTitle className="text-2xl mb-2">{coachPlan.name}</CardTitle>
                                <Badge variant="default" className="capitalize">
                                    {coachPlan.type}
                                </Badge>
                            </div>
                            <Trophy className="h-12 w-12 text-primary" />
                        </div>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground mb-4">
                            {coachPlan.description || "خطة تدريبية مخصصة من مدربك"}
                        </p>
                        {planStatus && (
                            <div className="flex gap-4 text-sm">
                                <div>
                                    <span className="text-muted-foreground">تاريخ البدء: </span>
                                    <span className="font-medium">
                                        {new Date(planStatus.started_at).toLocaleDateString('ar-EG')}
                                    </span>
                                </div>
                                <div>
                                    <span className="text-muted-foreground">تاريخ الانتهاء: </span>
                                    <span className="font-medium">
                                        {new Date(planStatus.expires_at).toLocaleDateString('ar-EG')}
                                    </span>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* تقدم اليوم */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Clock className="h-5 w-5" />
                            تقدم اليوم
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                                <span>
                                    {todayCheckedExercises.size} من {planMuscles.length} تمارين
                                </span>
                                <span className="font-bold">{Math.round(todayProgress)}%</span>
                            </div>
                            <Progress value={todayProgress} className="h-3" />
                        </div>
                    </CardContent>
                </Card>

                {/* التمارين اليومية */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Dumbbell className="h-5 w-5" />
                            التمارين ({planMuscles.length})
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {planMuscles.map((muscle, index) => {
                                const isChecked = todayCheckedExercises.has(muscle.id);
                                return (
                                    <div
                                        key={muscle.id}
                                        className={`flex items-center gap-3 p-4 rounded-lg border-2 transition-all ${
                                            isChecked
                                                ? 'bg-green-50 dark:bg-green-950 border-green-500'
                                                : 'bg-muted/50 border-muted'
                                        }`}
                                    >
                                        <Checkbox
                                            id={muscle.id}
                                            checked={isChecked}
                                            onCheckedChange={(checked) =>
                                                handleCheckExercise(muscle.id, checked as boolean)
                                            }
                                            className="h-6 w-6"
                                        />
                                        <label
                                            htmlFor={muscle.id}
                                            className="flex-1 cursor-pointer"
                                        >
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <h4 className="font-semibold text-lg">
                                                        {index + 1}. {muscle.muscle_name}
                                                    </h4>
                                                    <p className="text-sm text-muted-foreground">
                                                        {muscle.exercise_count} تمارين • {muscle.sets} مجموعات • {muscle.reps} تكرار
                                                    </p>
                                                    {muscle.equipment && (
                                                        <p className="text-xs text-muted-foreground mt-1">
                                                            معدات: {muscle.equipment}
                                                        </p>
                                                    )}
                                                    {muscle.exercise_description && (
                                                        <p className="text-xs text-muted-foreground mt-1">
                                                            {muscle.exercise_description}
                                                        </p>
                                                    )}
                                                </div>
                                                {isChecked && (
                                                    <Check className="h-6 w-6 text-green-600" />
                                                )}
                                            </div>
                                        </label>
                                    </div>
                                );
                            })}
                        </div>
                    </CardContent>
                </Card>

                {/* التقويم الشهري */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Calendar className="h-5 w-5" />
                            سجل التمارين الشهري
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-7 gap-2">
                            {['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'].map(day => (
                                <div
                                    key={day}
                                    className="text-center text-xs font-semibold text-muted-foreground p-2"
                                >
                                    {day}
                                </div>
                            ))}
                            {getMonthCalendar().map((day, index) => {
                                const workout = getDayWorkout(day);
                                const isToday =
                                    day === new Date().getDate() &&
                                    new Date().getMonth() === new Date().getMonth();

                                return (
                                    <div
                                        key={index}
                                        className={`aspect-square flex items-center justify-center rounded-lg text-sm font-medium relative ${
                                            !day
                                                ? 'bg-transparent'
                                                : isToday
                                                ? 'bg-primary text-primary-foreground ring-2 ring-primary'
                                                : workout
                                                ? 'bg-green-500 text-white'
                                                : 'bg-muted'
                                        }`}
                                    >
                                        {day}
                                        {workout && workout.completed_exercises.length > 0 && (
                                            <div className="absolute bottom-0.5 right-0.5">
                                                <Check className="h-3 w-3" />
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                        <div className="mt-4 flex gap-4 text-xs">
                            <div className="flex items-center gap-2">
                                <div className="w-4 h-4 rounded bg-green-500"></div>
                                <span>تم التمرين</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="w-4 h-4 rounded bg-primary"></div>
                                <span>اليوم</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="w-4 h-4 rounded bg-muted"></div>
                                <span>لم يتم</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </MainLayout>
    );
}
